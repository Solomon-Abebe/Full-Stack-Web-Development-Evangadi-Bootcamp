import React from "react";
import About from "../../components/About/About";

const Landing = () => {
  return (
    <div>
      <About />
    </div>
  );
};

export default Landing;
