//declare constant variables that define the action (string value)
export const USER_SIGNUP = "USER_SIGNUP";
export const USER_SIGNIN = "USER_SIGNIN";
export const USER_PASSWORD = "USER_PASSWORD";
export const STORE_USER = "STORE_USER";
export const REMOVE_USER = "REMOVE_USER";
